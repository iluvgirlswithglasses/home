# BlankPrivateBrowsingPage
Firefox extension to change the private browsing page to a blank page

I made this Firefox extension to remove the annoying message shown each time a new private window is opened, and just show a simple blank page.

Source code is in src directory. The extension could be installed directly by adding the xpi file to Firefox.
Submitted version to AMO for signature, fully reviewed, available here: https://addons.mozilla.org/addon/blank-private-browsing-page/
